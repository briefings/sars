
class Settings:

    def __init__(self):

        self.apistate = 'https://www2.census.gov/programs-surveys/popest/datasets/{segment}/' \
                        'state/detail/SCPRC-EST{year}-18+POP-RES.csv'
